#ifndef _PLACE
#define _PLACE
typedef struct place
{
    int id;
    char name[40];
    int threshold;
} PLACE;
#endif