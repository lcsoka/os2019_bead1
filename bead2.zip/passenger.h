#ifndef _PASSENGER
#define _PASSENGER
typedef struct passenger
{
    int id;
    char name[40];
    char phone[15];
    int place_id;
    int travel_type_id;
} PASSENGER;
#endif